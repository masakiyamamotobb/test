roslaunch arc_items spawn_eraser.launch

